# Keyboard Shortcuts (Stable)

## Navigation Layer (Caps Lock)
- **H/J/K/L**: Arrow Keys
- **F/G**: Word Movement
- **Space**: Enter / Escape (Tap)

## Window Layer (Cmd / Alt)
- **Cmd + H/J/K/L**: Focus Window
- **Cmd + Shift + H/J/K/L**: Move Window
- **Cmd + Enter**: Terminal
- **Cmd + T**: Float/Tile Toggle

## Workflow Layer (Cmd+Ctrl)
- **1**: Study Math
- **2**: Guitar
- **3**: Coding
- **4**: Email/Admin
- **`**: Gather Windows
