# Unified Keyboard Environment
**Single Source of Truth (Stable Remote)**

## 🏗️ Architecture
All configurations in this repository are considered **Stable**. Local changes on machines are considered **Drift**.
Run `./install.sh` to enforce this repository's state onto the local system.

## 📂 Structure
- **install.sh**: The enforcer. Backs up local drift and links repo files.
- **local-bin/**: Scripts added to PATH.
- **workflow/**: Context definitions (Bunches).
- **docs/**: Reference documentation.
