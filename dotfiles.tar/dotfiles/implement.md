This document defines the **exact structure and infrastructure files** required to transform the current `dotfiles` repository into the unified Git-native environment.

It includes:

1.  The **Directory Tree** definition.
2.  The **Automation Scripts** (`install.sh`) to manage symlinks.
3.  The **Migration Script** to move your existing `workflow/` tools into this new structure.

-----

# Unified Dotfiles Structure Definition

## 1\. Target Directory Architecture

This tree represents the final state of the `~/dotfiles` repository.

```text
~/dotfiles/
├── .git/
├── .gitignore
├── .stow-local-ignore            # New: Prevents stowing git/DS_Store files
├── install.sh                    # New: The main installer script
├── README.md
│
├── local-bin/                    # New Package: Personal Scripts
│   └── .local/
│       └── bin/                  # Maps to ~/.local/bin
│           ├── bunch-manager     # (Migrated from workflow/scripts)
│           ├── gather-current-space
│           └── lib-os-detect
│
├── workflow/                     # New Package: Context Definitions
│   └── bunches/                  # Maps to ~/bunches
│       ├── coding-project.sh
│       ├── study-math.sh
│       └── ... (other context files)
│
├── nvim/                         # Existing Package
├── zsh/                          # Existing Package
├── wezterm/                      # Existing Package
├── tmux/                         # Existing Package
└── (other config folders)
```

-----

## 2\. Infrastructure Files

The following code blocks represent the exact content for the new infrastructure files.

### File: `install.sh`

> **Location:** `~/dotfiles/install.sh`
> **Purpose:** Detects the OS and automatically symlinks (stows) the correct packages to the home directory.

```bash
#!/usr/bin/env bash

# ==========================================
# Unified Environment Installer (Git-Native)
# ==========================================
# Usage: ./install.sh
# This script MUST be run from inside the dotfiles directory.

# 1. Setup Environment
# ==========================================
# Ensure we are in the directory of the script
cd "$(dirname "${BASH_SOURCE[0]}")"
DOTFILES_DIR=$(pwd)
TARGET_DIR="$HOME"

# Colors
GREEN='\033[0;32m'
BLUE='\033[0;34m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m'

log() { echo -e "${BLUE}[INFO]${NC} $1"; }
success() { echo -e "${GREEN}[OK]${NC} $1"; }
warn() { echo -e "${YELLOW}[WARN]${NC} $1"; }
error() { echo -e "${RED}[ERROR]${NC} $1"; }

log "Setting up dotfiles from: $DOTFILES_DIR"

# 2. Detect OS
# ==========================================
OS="$(uname -s)"
case "$OS" in
    Linux*)     MACHINE="Linux";;
    Darwin*)    MACHINE="Mac";;
    *)          error "Unknown OS"; exit 1;;
esac
success "Detected System: $MACHINE"

# 3. Prerequisites Check
# ==========================================
if ! command -v stow &> /dev/null; then
    error "GNU Stow is not installed!"
    echo "  -> macOS: brew install stow"
    echo "  -> Linux: sudo pacman -S stow  (or apt install stow)"
    exit 1
fi

# 4. Prepare Target Directories
# ==========================================
# We must ensure specific target directories exist so Stow doesn't 
# symlink the whole folder (which would prevent adding other files later).
mkdir -p "$HOME/.config"
mkdir -p "$HOME/.local/bin"
mkdir -p "$HOME/bunches"

# 5. Define Packages
# ==========================================
# Core packages installed on ALL systems
COMMON_PKGS=(
    "local-bin"   # Scripts (mapped to ~/.local/bin)
    "workflow"    # Contexts (mapped to ~/bunches)
    "nvim"
    "wezterm"
    "tmux"
    "zsh"
    "git"
    "starship"
)

# OS-specific packages
LINUX_PKGS=("hyprland" "waybar" "keyd")
MAC_PKGS=("yabai" "skhd" "karabiner")

# 6. Core Logic
# ==========================================
stow_package() {
    local pkg=$1
    if [ -d "$DOTFILES_DIR/$pkg" ]; then
        # -v: verbose, -R: restow (refresh), -t: target
        # We suppress standard output to keep it clean, show errors only
        stow -R -t "$TARGET_DIR" -d "$DOTFILES_DIR" "$pkg" 2>/dev/null
        
        if [ $? -eq 0 ]; then
            success "$pkg linked"
        else
            warn "Conflict in $pkg. Attempting to adopt..."
            # Attempt to adopt existing files (incorporate them into stow)
            stow --adopt -t "$TARGET_DIR" -d "$DOTFILES_DIR" "$pkg" 2>/dev/null
            if [ $? -eq 0 ]; then
                success "$pkg adopted"
                # Reset git changes caused by adoption if you want to keep repo clean
                # git checkout . 
            else
                error "Failed to link $pkg (Manual intervention required)"
            fi
        fi
    else
        warn "Skipping $pkg (Directory not found)"
    fi
}

# 7. Execution
# ==========================================

log "Installing Common Packages..."
for pkg in "${COMMON_PKGS[@]}"; do
    stow_package "$pkg"
done

if [ "$MACHINE" == "Linux" ]; then
    log "Installing Linux Packages..."
    for pkg in "${LINUX_PKGS[@]}"; do
        stow_package "$pkg"
    done
elif [ "$MACHINE" == "Mac" ]; then
    log "Installing macOS Packages..."
    for pkg in "${MAC_PKGS[@]}"; do
        stow_package "$pkg"
    done
fi

log "Running post-install hooks..."
# Reload zshrc if it exists
if [ -f "$HOME/.zshrc" ]; then
    source "$HOME/.zshrc" 2>/dev/null || true
fi

echo -e "\n${GREEN}âœ¨ Dotfiles installation complete!${NC}"
echo "Please restart your terminal or run 'source ~/.zshrc'"
```

-----

### File: `.stow-local-ignore`

> **Location:** `~/dotfiles/.stow-local-ignore`
> **Purpose:** Tells GNU Stow to strictly ignore Git metadata and system artifacts when creating symlinks.

```text
\.git
\.gitignore
\.DS_Store
\.stow-local-ignore
README.md
LICENSE
install.sh
migrate_legacy.sh
scripts
docs
```

-----

## 3\. Migration Tool

This script is designed to run **ONCE** to move your files from the old `~/workflow` folder into this new `~/dotfiles` structure.

### File: `migrate_legacy.sh`

> **Location:** `~/dotfiles/migrate_legacy.sh`
> **Purpose:** One-time migration of existing scripts and bunches into the new architecture.

```bash
#!/usr/bin/env bash

# Source and Destination
WORKFLOW_SRC="$HOME/workflow"
DOTFILES_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

echo "Migrating from $WORKFLOW_SRC to $DOTFILES_DIR..."

# 1. Create the Stow-compatible directory structure
# -------------------------------------------------
echo "Creating directory structure..."
mkdir -p "$DOTFILES_DIR/local-bin/.local/bin"
mkdir -p "$DOTFILES_DIR/workflow/bunches"
mkdir -p "$DOTFILES_DIR/scripts/maintenance"

# 2. Migrate Scripts (and rename to remove .sh extension)
# -------------------------------------------------
echo "Migrating Scripts to local-bin..."

# Helper function to move if exists
move_script() {
    if [ -f "$WORKFLOW_SRC/scripts/$1.sh" ]; then
        cp "$WORKFLOW_SRC/scripts/$1.sh" "$DOTFILES_DIR/local-bin/.local/bin/$1"
        chmod +x "$DOTFILES_DIR/local-bin/.local/bin/$1"
        echo "  [+] Moved $1"
    else
        echo "  [!] Warning: $1.sh not found in source"
    fi
}

move_script "bunch-manager"
move_script "gather-current-space"
move_script "lib-os-detect"

# Move AI collector to maintenance scripts (not bin path)
if [ -f "$WORKFLOW_SRC/scripts/collect-for-ai.sh" ]; then
    cp "$WORKFLOW_SRC/scripts/collect-for-ai.sh" "$DOTFILES_DIR/scripts/maintenance/collect-for-ai.sh"
    chmod +x "$DOTFILES_DIR/scripts/maintenance/collect-for-ai.sh"
    echo "  [+] Moved collect-for-ai.sh"
fi

# 3. Migrate Bunches
# -------------------------------------------------
echo "Migrating Bunches..."
if [ -d "$WORKFLOW_SRC/bunches" ]; then
    cp -r "$WORKFLOW_SRC/bunches/"* "$DOTFILES_DIR/workflow/bunches/"
    echo "  [+] Copied all bunches"
else
    echo "  [!] Bunches directory not found at source"
fi

echo "------------------------------------------------"
echo "Migration prepared."
echo "Run ./install.sh to symlink these files to your system."
```

-----

### 4\. Post-Creation Instructions

After your CLI creates these files:

1.  **Make scripts executable:**

    ```bash
    chmod +x ~/dotfiles/install.sh
    chmod +x ~/dotfiles/migrate_legacy.sh
    ```

2.  **Run Migration (If you have the old folder):**

    ```bash
    cd ~/dotfiles
    ./migrate_legacy.sh
    ```

3.  **Run Installation:**

    ```bash
    ./install.sh
    ```
