#!/usr/bin/env bash
# ==============================================================================
# BUNCH: [BUNCH_NAME]
# Description: [DESCRIPTION]
# ==============================================================================

# Load OS detection library
source "$(dirname "$0")/../bunches/lib-os-detect.sh"

# ─────────────────────────────────────────────────────────────────────────────
# Configuration
# ─────────────────────────────────────────────────────────────────────────────
BUNCH_NAME="[BUNCH_NAME]"
PRIMARY_SPACE=1  # Main workspace for this bunch

# ─────────────────────────────────────────────────────────────────────────────
# Startup Sequence
# ─────────────────────────────────────────────────────────────────────────────
echo "🚀 Starting bunch: $BUNCH_NAME"

# Switch to primary workspace
$WM_FOCUS_SPACE $PRIMARY_SPACE

# Launch applications (uncomment and customize)
# launch_app "browser"
# sleep 1
# launch_app "notes"
# sleep 1
# launch_app "terminal"

echo "✅ Bunch '$BUNCH_NAME' ready!"
echo "   → Workspace: $PRIMARY_SPACE"

# ─────────────────────────────────────────────────────────────────────────────
# Optional: Additional Setup
# ─────────────────────────────────────────────────────────────────────────────
# cd ~/Projects/my-project
# tmux new-session -d -s $BUNCH_NAME
