#!/usr/bin/env bash
# ==============================================================================
# UKE Installer v6.3 - Arch Linux Ready
# ==============================================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
UKE_ROOT="${SCRIPT_DIR%/scripts}"

# Colors
RED=$'\e[31m' GREEN=$'\e[32m' YELLOW=$'\e[33m' BLUE=$'\e[34m'
BOLD=$'\e[1m' DIM=$'\e[2m' RESET=$'\e[0m'

ok()   { echo "${GREEN}✓${RESET} $*"; }
fail() { echo "${RED}✗${RESET} $*"; }
info() { echo "${BLUE}→${RESET} $*"; }
warn() { echo "${YELLOW}!${RESET} $*"; }

# ==============================================================================
# OS & Distro Detection
# ==============================================================================
case "$(uname -s)" in
    Darwin) OS="macos" ;;
    Linux)  OS="linux" ;;
    *)      echo "Unsupported OS"; exit 1 ;;
esac

# Detect Linux distribution
DISTRO=""
if [[ "$OS" == "linux" ]]; then
    if [[ -f /etc/arch-release ]]; then
        DISTRO="arch"
    elif [[ -f /etc/debian_version ]]; then
        DISTRO="debian"
    elif [[ -f /etc/fedora-release ]]; then
        DISTRO="fedora"
    else
        DISTRO="unknown"
    fi
fi

# ==============================================================================
# Package Manager Detection
# ==============================================================================
get_pkg_manager() {
    if [[ "$OS" == "macos" ]]; then
        echo "brew"
    elif command -v pacman &>/dev/null; then
        echo "pacman"
    elif command -v apt &>/dev/null; then
        echo "apt"
    elif command -v dnf &>/dev/null; then
        echo "dnf"
    else
        echo "unknown"
    fi
}

PKG_MANAGER=$(get_pkg_manager)

# ==============================================================================
# Dependency Check
# ==============================================================================
check_deps() {
    info "Checking dependencies..."
    local missing=()
    
    # Core dependencies (all platforms)
    for cmd in git stow jq; do
        command -v "$cmd" &>/dev/null || missing+=("$cmd")
    done
    
    if [[ "$OS" == "macos" ]]; then
        command -v yabai &>/dev/null || missing+=("yabai")
        command -v skhd &>/dev/null || missing+=("skhd")
        command -v yq &>/dev/null || missing+=("yq")
    else
        command -v hyprctl &>/dev/null || missing+=("hyprland")
        command -v keyd &>/dev/null || missing+=("keyd")
    fi
    
    if [[ ${#missing[@]} -gt 0 ]]; then
        fail "Missing dependencies: ${missing[*]}"
        echo ""
        echo "Install with:"
        case "$PKG_MANAGER" in
            brew)
                echo "  brew install ${missing[*]}"
                ;;
            pacman)
                # Map package names for Arch
                local arch_pkgs=""
                for pkg in "${missing[@]}"; do
                    case "$pkg" in
                        hyprland) arch_pkgs+="hyprland " ;;
                        keyd)     arch_pkgs+="keyd " ;;
                        *)        arch_pkgs+="$pkg " ;;
                    esac
                done
                echo "  sudo pacman -S $arch_pkgs"
                echo ""
                echo "  # For AUR packages (if needed):"
                echo "  yay -S ${missing[*]}"
                ;;
            apt)
                echo "  sudo apt install ${missing[*]}"
                ;;
            dnf)
                echo "  sudo dnf install ${missing[*]}"
                ;;
            *)
                echo "  Please install: ${missing[*]}"
                ;;
        esac
        exit 1
    fi
    
    ok "All dependencies installed"
}

# ==============================================================================
# Generate Configs
# ==============================================================================
generate_configs() {
    info "Generating configs..."
    bash "$UKE_ROOT/lib/gen.sh" all
}

# ==============================================================================
# Create Directories
# ==============================================================================
create_dirs() {
    info "Creating directories..."
    mkdir -p ~/.local/bin
    mkdir -p ~/.config/skhd
    mkdir -p ~/.config/yabai
    mkdir -p ~/.config/hypr
    mkdir -p ~/.config/keyd
    mkdir -p ~/.local/state/uke
    ok "Directories created"
}

# ==============================================================================
# Link Binaries
# ==============================================================================
link_binaries() {
    info "Linking binaries to ~/.local/bin..."
    
    for bin in "$UKE_ROOT/bin"/*; do
        [[ -f "$bin" ]] || continue
        local name=$(basename "$bin")
        chmod +x "$bin"
        ln -sf "$bin" "$HOME/.local/bin/$name"
        ok "Linked: $name"
    done
}

# ==============================================================================
# Link Generated Configs
# ==============================================================================
link_configs() {
    info "Linking generated configs..."
    
    if [[ "$OS" == "macos" ]]; then
        ln -sf "$UKE_ROOT/gen/skhd/skhdrc" "$HOME/.config/skhd/skhdrc"
        ok "Linked: skhdrc"
        
        ln -sf "$UKE_ROOT/gen/yabai/yabairc" "$HOME/.config/yabai/yabairc"
        ok "Linked: yabairc"
    else
        # Hyprland config
        ln -sf "$UKE_ROOT/gen/hyprland/hyprland.conf" "$HOME/.config/hypr/hyprland.conf"
        ok "Linked: hyprland.conf"
    fi
}

# ==============================================================================
# Stow Dotfiles
# ==============================================================================
stow_dotfiles() {
    info "Stowing dotfiles..."
    cd "$UKE_ROOT/stow"
    
    # Common packages
    local packages=(wezterm tmux zsh nvim)
    
    # Platform-specific packages
    if [[ "$OS" == "macos" ]]; then
        packages+=(karabiner)
    fi
    
    for pkg in "${packages[@]}"; do
        if [[ -d "$pkg" ]]; then
            stow -t "$HOME" -R "$pkg" 2>/dev/null && ok "Stowed: $pkg" || warn "Skipped: $pkg"
        fi
    done
}

# ==============================================================================
# Setup keyd (Linux only - requires sudo)
# ==============================================================================
setup_keyd() {
    if [[ "$OS" != "linux" ]]; then
        return 0
    fi
    
    if ! command -v keyd &>/dev/null; then
        warn "keyd not installed, skipping keyd setup"
        return 0
    fi
    
    info "Setting up keyd..."
    
    local keyd_config="$UKE_ROOT/stow/keyd/.config/keyd/default.conf"
    
    if [[ ! -f "$keyd_config" ]]; then
        warn "keyd config not found at $keyd_config"
        return 1
    fi
    
    # Check if we have sudo access
    if ! sudo -n true 2>/dev/null; then
        warn "keyd requires sudo to link to /etc/keyd/"
        echo ""
        echo "${YELLOW}To complete keyd setup, run:${RESET}"
        echo "  sudo mkdir -p /etc/keyd"
        echo "  sudo ln -sf $keyd_config /etc/keyd/default.conf"
        echo "  sudo systemctl enable --now keyd"
        echo ""
        return 0
    fi
    
    # We have sudo, do the setup
    sudo mkdir -p /etc/keyd
    sudo ln -sf "$keyd_config" /etc/keyd/default.conf
    ok "Linked keyd config to /etc/keyd/"
    
    # Enable and start keyd service
    if systemctl is-enabled keyd &>/dev/null; then
        sudo systemctl restart keyd
        ok "keyd service restarted"
    else
        sudo systemctl enable --now keyd
        ok "keyd service enabled and started"
    fi
}

# ==============================================================================
# Make Bunches Executable
# ==============================================================================
setup_bunches() {
    info "Setting up bunches..."
    chmod +x "$UKE_ROOT/bunches"/*.sh 2>/dev/null || true
    chmod +x "$UKE_ROOT/templates"/*.sh 2>/dev/null || true
    ok "Bunches ready"
}

# ==============================================================================
# Start Services
# ==============================================================================
start_services() {
    info "Starting services..."
    
    if [[ "$OS" == "macos" ]]; then
        yabai --restart-service 2>/dev/null && ok "yabai restarted" || warn "yabai restart failed"
        skhd --restart-service 2>/dev/null && ok "skhd restarted" || warn "skhd restart failed"
    else
        # Hyprland reloads automatically when config changes
        if [[ -n "${HYPRLAND_INSTANCE_SIGNATURE:-}" ]]; then
            hyprctl reload 2>/dev/null && ok "hyprland reloaded" || warn "hyprland reload failed"
        else
            warn "Hyprland not running - config will load on next start"
        fi
    fi
}

# ==============================================================================
# Print Arch-specific Help
# ==============================================================================
print_arch_help() {
    if [[ "$OS" != "linux" ]] || [[ "$DISTRO" != "arch" ]]; then
        return 0
    fi
    
    echo ""
    echo "${BOLD}Arch Linux Notes:${RESET}"
    echo ""
    echo "  ${DIM}# Recommended packages:${RESET}"
    echo "  sudo pacman -S hyprland keyd waybar dunst wofi grim slurp wl-clipboard cliphist"
    echo "  sudo pacman -S wezterm neovim stow jq ripgrep fd"
    echo ""
    echo "  ${DIM}# Optional AUR packages:${RESET}"
    echo "  yay -S brave-bin obsidian-bin spotify"
    echo ""
    echo "  ${DIM}# Enable keyd service:${RESET}"
    echo "  sudo systemctl enable --now keyd"
    echo ""
}

# ==============================================================================
# Main
# ==============================================================================
main() {
    echo ""
    echo "${BOLD}╔══════════════════════════════════════╗${RESET}"
    echo "${BOLD}║     UKE v6.3 Installer               ║${RESET}"
    echo "${BOLD}╚══════════════════════════════════════╝${RESET}"
    echo ""
    echo "Platform: $OS"
    [[ -n "$DISTRO" ]] && echo "Distro:   $DISTRO"
    echo "UKE Root: $UKE_ROOT"
    echo ""
    
    case "${1:-full}" in
        --check)
            check_deps
            ;;
        --stow)
            stow_dotfiles
            ;;
        --link)
            link_binaries
            link_configs
            ;;
        --gen)
            generate_configs
            ;;
        --keyd)
            setup_keyd
            ;;
        full|*)
            check_deps
            create_dirs
            generate_configs
            link_binaries
            link_configs
            stow_dotfiles
            setup_bunches
            setup_keyd
            start_services
            
            echo ""
            echo "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
            echo "${GREEN}✓ Installation complete!${RESET}"
            echo ""
            echo "Next steps:"
            echo "  1. Restart your terminal (or run: source ~/.zshrc)"
            echo "  2. Test with: uke status"
            echo "  3. See: docs/CHEATSHEET.md for keybindings"
            
            print_arch_help
            ;;
    esac
}

main "$@"
