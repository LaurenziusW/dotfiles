# UKE v7.0 - Unified Keyboard Environment

**One muscle memory for macOS & Linux** — with hardware adaptation.

## Architecture

UKE v7.0 introduces the **Ghost File Architecture**: a clean separation between version-controlled code and machine-specific state.

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                          VERSION CONTROLLED (Git)                           │
│  ┌────────────────┐   ┌────────────────┐   ┌────────────────┐              │
│  │ registry.yaml  │   │    lib/*.sh    │   │   bin/uke      │              │
│  │ (software)     │   │  (generators)  │   │    (CLI)       │              │
│  └───────┬────────┘   └───────┬────────┘   └────────────────┘              │
│          │                    │                                             │
│          └──────────┬─────────┘                                             │
│                     ▼                                                       │
│              ┌──────────────┐                                               │
│              │   uke gen    │                                               │
│              └──────┬───────┘                                               │
└─────────────────────│───────────────────────────────────────────────────────┘
                      │
                      ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                            LOCAL ONLY (.gitignored)                         │
│  ┌────────────────┐   ┌─────────────────────────────────────────────────┐  │
│  │machine.profile │   │ hyprland.conf  │  skhdrc  │  yabairc            │  │
│  │  (hardware)    │   │         (includes source = generated_*.conf)    │  │
│  └───────┬────────┘   └─────────────────────────────────────────────────┘  │
│          │                              ▲                                   │
│          ▼                              │                                   │
│  ┌────────────────┐   ┌─────────────────┴───────────────────────────────┐  │
│  │ uke profile    │──▶│ generated_hardware.conf │ generated_font.toml   │  │
│  │    (TUI)       │   │                  (hardware snippets)            │  │
│  └────────────────┘   └─────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────────────────┘
```

## Key Concepts

### 1. Software Preferences (registry.yaml)
Version-controlled. Defines keybindings, workspace assignments, app mappings.

### 2. Hardware Profile (machine.profile)
Local-only. Stores machine identity: GPU type, monitor count, form factor.

### 3. Generated Configs
Output of the two inputs above. Gitignored. Regenerated on each machine.

## Quick Start

```bash
# 1. Clone
git clone https://github.com/you/uke ~/dotfiles/uke
cd ~/dotfiles/uke

# 2. Configure hardware (auto-detects on first run)
uke profile

# 3. Generate configs
uke gen

# 4. Reload window manager
uke reload
```

## Commands

| Command | Description |
|---------|-------------|
| `uke profile` | Open hardware profile TUI |
| `uke profile --show` | Display current profile |
| `uke profile --apply` | Regenerate hardware configs |
| `uke profile --reset` | Reset to auto-detected |
| `uke gen` | Generate all configs from registry.yaml |
| `uke reload` | Reload window manager |
| `uke apply` | Full cycle: profile → gen → reload |
| `uke status` | Show system status |
| `uke validate` | Validate configuration |
| `uke edit [target]` | Edit config (registry, profile, etc.) |

## Hardware Profile

The profile manager (`uke profile`) configures:

| Setting | Options | Effect |
|---------|---------|--------|
| OS | arch, macos | Platform-specific generation |
| Form Factor | desktop, laptop_14, laptop_10 | Font size, gaps, padding |
| Monitors | 1, 2, 3 | Workspace-to-monitor assignment |
| GPU | integrated, nvidia, amd | Wayland env vars, cursor fix |
| Keyboard | pc, mac | Alt/Super swap |

### Form Factor Effects

| Form Factor | Font | Gaps In | Gaps Out | Use Case |
|-------------|------|---------|----------|----------|
| desktop | 11pt | 3px | 6px | External monitor |
| laptop_14 | 12.5pt | 2px | 4px | Standard laptop |
| laptop_10 | 10pt | 1px | 2px | Small/portable |

### GPU Settings (Linux)

When GPU=nvidia, these env vars are set:
```
WLR_NO_HARDWARE_CURSORS=1
__GLX_VENDOR_LIBRARY_NAME=nvidia
GBM_BACKEND=nvidia-drm
```

## Cloud Storage

Sync your configs across machines by setting `UKE_CLOUD_PATH`:

```bash
# In ~/.zshrc or ~/.bashrc
export UKE_CLOUD_PATH="$HOME/Dropbox/dotfiles/uke"

# Or for iCloud
export UKE_CLOUD_PATH="$HOME/Library/Mobile Documents/com~apple~CloudDocs/uke"
```

When set, UKE reads `registry.yaml` from the cloud path instead of `~/dotfiles/uke/config`.

## Dynamic Generation

Unlike previous versions, gen.sh now **parses registry.yaml dynamically**:

```yaml
# registry.yaml
workspaces:
  3:
    name: "code"
    apps: [wezterm, code, xcode]
```

Becomes (in skhdrc):
```
# Workspace 3: code
cmd - 3 : yabai -m space --focus 3
cmd + shift - 3 : yabai -m window --space 3 --focus
```

And (in yabairc):
```
# Workspace 3: code
yabai -m rule --add app="^WezTerm$" space=^3
yabai -m rule --add app="^Code$" space=^3
yabai -m rule --add app="^Xcode$" space=^3
```

## File Locations

### Version Controlled
```
~/dotfiles/uke/
├── config/registry.yaml     # Software preferences
├── lib/
│   ├── core.sh              # Foundation + cloud storage
│   ├── gen.sh               # Dynamic generator
│   └── wm.sh                # WM abstraction
├── bin/uke                  # Main CLI
├── scripts/
│   ├── manage_profile.sh    # Hardware TUI
│   └── apply_profile.sh     # Hardware generator
└── gen/                     # Templates (with source = lines)
```

### Local Only (Gitignored)
```
~/.local/state/uke/
└── machine.profile          # Hardware identity

~/.config/hypr/
└── generated_hardware.conf  # GPU, monitors, gaps

~/.config/alacritty/
└── generated_font.toml      # Font size

~/.config/wezterm/
└── generated_hardware.lua   # Font, GPU, OS info

~/.config/yabai/
└── generated_hardware.conf  # Padding, gaps
```

## .gitignore

Add these to your dotfiles repo:

```gitignore
# UKE Ghost Files
**/machine.profile
**/generated_*.conf
**/generated_*.toml
**/generated_*.lua
**/registry.local.yaml
```

## Modifier Hierarchy

| Layer | macOS | Linux | Scope |
|-------|-------|-------|-------|
| PRIMARY | Cmd | Alt | Window Manager |
| +SHIFT | Cmd+Shift | Alt+Shift | Move Windows |
| SECONDARY | Alt | Super | Terminal (WezTerm) |
| TERTIARY | Alt+Shift | Super+Shift | Resize |
| QUATERNARY | Ctrl | Ctrl | Shell (never intercept) |
| LAUNCHER | Cmd+Alt | Alt+Super | App Launch |
| BUNCH | Cmd+Ctrl | Alt+Ctrl | Environments |

## Fresh Clone Workflow

```bash
# On new machine:
cd ~/dotfiles/uke

# 1. Run installer
./scripts/install.sh

# 2. Configure hardware (auto-detects)
uke profile
# Press [s] to save

# 3. Generate all configs
uke gen

# 4. Reload
uke reload

# Done! Same workflow as your other machines.
```

## Troubleshooting

### yq not found
```bash
# macOS
brew install yq

# Arch
sudo pacman -S yq
```

### Profile not found
```bash
uke profile  # Creates on first run
```

### Generated configs missing
```bash
uke profile --apply  # Regenerate hardware configs
uke gen              # Regenerate main configs
```

### Configs not applying
```bash
uke validate  # Check for errors
uke apply     # Full regeneration cycle
```

## Migration from v6

1. Run `uke profile` to create hardware profile
2. Your existing `registry.yaml` should work
3. Generated configs now include `source = generated_hardware.conf`
4. Add gitignore entries for ghost files
