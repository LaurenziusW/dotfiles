#!/usr/bin/env bash
# ==============================================================================
# UKE Core Library v7.0 - Unified Configuration System
# ==============================================================================
# Foundation library with:
#   - Cloud storage support (UKE_CLOUD_PATH)
#   - Dynamic path resolution
#   - Hardware profile integration
# ==============================================================================
set -euo pipefail

[[ -n "${_UKE_CORE_LOADED:-}" ]] && return 0
readonly _UKE_CORE_LOADED=1

# ==============================================================================
# Path Resolution
# ==============================================================================
_resolve_uke_root() {
    local src="${BASH_SOURCE[1]:-${BASH_SOURCE[0]}}"
    while [[ -L "$src" ]]; do
        local dir="$(cd -P "$(dirname "$src")" && pwd)"
        src="$(readlink "$src")"
        [[ "$src" != /* ]] && src="$dir/$src"
    done
    cd -P "$(dirname "$src")/.." && pwd
}

export UKE_ROOT="${UKE_ROOT:-$(_resolve_uke_root)}"
export UKE_VERSION="7.0.0"

# ==============================================================================
# Cloud Storage / Filesystem Agnosticism
# ==============================================================================
# Priority order for config location:
#   1. UKE_CLOUD_PATH environment variable (if set)
#   2. UKE_CONFIG_PATH environment variable (if set)
#   3. Default: $UKE_ROOT/config
#
# This allows configs to live in:
#   - Dropbox:     export UKE_CLOUD_PATH="$HOME/Dropbox/dotfiles/uke"
#   - iCloud:      export UKE_CLOUD_PATH="$HOME/Library/Mobile Documents/com~apple~CloudDocs/uke"
#   - Syncthing:   export UKE_CLOUD_PATH="$HOME/Sync/uke"
#   - Git subdir:  export UKE_CONFIG_PATH="$HOME/dotfiles/uke/config"
# ==============================================================================

resolve_config_path() {
    if [[ -n "${UKE_CLOUD_PATH:-}" ]] && [[ -d "${UKE_CLOUD_PATH}" ]]; then
        echo "${UKE_CLOUD_PATH}"
    elif [[ -n "${UKE_CONFIG_PATH:-}" ]] && [[ -d "${UKE_CONFIG_PATH}" ]]; then
        echo "${UKE_CONFIG_PATH}"
    else
        echo "${UKE_ROOT}/config"
    fi
}

# ==============================================================================
# Directory Structure
# ==============================================================================
export UKE_LIB="${UKE_ROOT}/lib"
export UKE_BIN="${UKE_ROOT}/bin"
export UKE_CONFIG="$(resolve_config_path)"
export UKE_GEN="${UKE_ROOT}/gen"
export UKE_STOW="${UKE_ROOT}/stow"
export UKE_BUNCHES="${UKE_ROOT}/bunches"
export UKE_SCRIPTS="${UKE_ROOT}/scripts"
export UKE_DOCS="${UKE_ROOT}/docs"

# XDG-compliant state directory
export UKE_STATE="${XDG_STATE_HOME:-$HOME/.local/state}/uke"
export UKE_LOG_FILE="${UKE_STATE}/uke.log"
export UKE_PROFILE_FILE="${UKE_STATE}/machine.profile"

# Create state directory
mkdir -p "${UKE_STATE}" 2>/dev/null || true

# ==============================================================================
# Platform Detection
# ==============================================================================
case "$(uname -s)" in
    Darwin) export UKE_OS="macos" ;;
    Linux)  export UKE_OS="linux" ;;
    *)      export UKE_OS="unknown" ;;
esac

# Distro detection for Linux
if [[ "${UKE_OS}" == "linux" ]]; then
    if [[ -f /etc/arch-release ]]; then
        export UKE_DISTRO="arch"
    elif [[ -f /etc/debian_version ]]; then
        export UKE_DISTRO="debian"
    elif [[ -f /etc/fedora-release ]]; then
        export UKE_DISTRO="fedora"
    else
        export UKE_DISTRO="unknown"
    fi
else
    export UKE_DISTRO=""
fi

is_macos() { [[ "${UKE_OS}" == "macos" ]]; }
is_linux() { [[ "${UKE_OS}" == "linux" ]]; }

# ==============================================================================
# Hardware Profile Loading
# ==============================================================================
# Loads machine-specific settings from the profile file.
# These are used by both gen.sh and apply_profile.sh
# ==============================================================================
load_hardware_profile() {
    if [[ -f "${UKE_PROFILE_FILE}" ]]; then
        # shellcheck source=/dev/null
        source "${UKE_PROFILE_FILE}"
        return 0
    fi
    return 1
}

# Export hardware variables with defaults if profile not loaded
export_hardware_defaults() {
    export UKE_HW_OS="${UKE_HW_OS:-${UKE_OS}}"
    export UKE_HW_FORM_FACTOR="${UKE_HW_FORM_FACTOR:-desktop}"
    export UKE_HW_MONITORS="${UKE_HW_MONITORS:-1}"
    export UKE_HW_GPU="${UKE_HW_GPU:-integrated}"
    export UKE_HW_KEYBOARD="${UKE_HW_KEYBOARD:-pc}"
}

# Try to load profile, fall back to defaults
if ! load_hardware_profile; then
    export_hardware_defaults
fi

# ==============================================================================
# Colors
# ==============================================================================
if [[ -t 1 ]]; then
    readonly C_RED=$'\e[31m'
    readonly C_GREEN=$'\e[32m'
    readonly C_YELLOW=$'\e[33m'
    readonly C_BLUE=$'\e[34m'
    readonly C_MAGENTA=$'\e[35m'
    readonly C_CYAN=$'\e[36m'
    readonly C_BOLD=$'\e[1m'
    readonly C_DIM=$'\e[2m'
    readonly C_RESET=$'\e[0m'
else
    readonly C_RED='' C_GREEN='' C_YELLOW='' C_BLUE='' 
    readonly C_MAGENTA='' C_CYAN='' C_BOLD='' C_DIM='' C_RESET=''
fi

# ==============================================================================
# Logging
# ==============================================================================
_log() {
    local level="$1" color="$2"
    shift 2
    local ts
    ts="$(date '+%H:%M:%S')"
    printf "%s[%s]%s %s%s%s %s\n" "${C_DIM}" "${ts}" "${C_RESET}" "${color}" "${level}" "${C_RESET}" "$*" >&2
    if [[ -w "${UKE_STATE}" ]]; then
        printf "[%s] [%s] %s\n" "$(date '+%Y-%m-%d %H:%M:%S')" "${level}" "$*" >> "${UKE_LOG_FILE}"
    fi
}

log_debug() { [[ -n "${UKE_DEBUG:-}" ]] && _log "DEBUG" "${C_BLUE}" "$@"; }
log_info()  { _log "INFO " "${C_GREEN}" "$@"; }
log_warn()  { _log "WARN " "${C_YELLOW}" "$@"; }
log_error() { _log "ERROR" "${C_RED}" "$@"; }
log_fatal() { _log "FATAL" "${C_RED}" "$@"; exit 1; }

ok()   { printf "%s✓%s %s\n" "${C_GREEN}" "${C_RESET}" "$*"; }
fail() { printf "%s✗%s %s\n" "${C_RED}" "${C_RESET}" "$*"; }
warn() { printf "%s!%s %s\n" "${C_YELLOW}" "${C_RESET}" "$*"; }
info() { printf "%s→%s %s\n" "${C_BLUE}" "${C_RESET}" "$*"; }

# ==============================================================================
# Utilities
# ==============================================================================
require_cmd() {
    for cmd in "$@"; do
        command -v "$cmd" &>/dev/null || log_fatal "Required command not found: $cmd"
    done
}

require_file() {
    for f in "$@"; do
        [[ -f "$f" ]] || log_fatal "Required file not found: $f"
    done
}

run() {
    log_debug "exec: $*"
    if [[ -n "${UKE_DRY_RUN:-}" ]]; then
        log_info "[dry-run] $*"
        return 0
    fi
    "$@"
}

# Atomic file write (temp file + move)
atomic_write() {
    local dest="$1"
    local content
    content=$(cat)
    
    mkdir -p "$(dirname "${dest}")"
    local temp_file
    temp_file=$(mktemp)
    printf '%s\n' "${content}" > "${temp_file}"
    mv "${temp_file}" "${dest}"
}

# ==============================================================================
# YAML Helpers (using yq)
# ==============================================================================
# Safe yq wrapper that handles missing keys gracefully
yq_safe() {
    local query="$1"
    local file="$2"
    local default="${3:-}"
    
    if ! command -v yq &>/dev/null; then
        log_warn "yq not installed, returning default"
        echo "${default}"
        return 0
    fi
    
    local result
    result=$(yq "${query} | select(. != null)" "${file}" 2>/dev/null) || result=""
    
    if [[ -z "${result}" ]]; then
        echo "${default}"
    else
        echo "${result}"
    fi
}

# Get array from YAML as bash array
yq_array() {
    local query="$1"
    local file="$2"
    
    if ! command -v yq &>/dev/null; then
        return 1
    fi
    
    yq "${query} | .[]" "${file}" 2>/dev/null | tr -d '"' || true
}

# Check if YAML key exists
yq_exists() {
    local query="$1"
    local file="$2"
    
    if ! command -v yq &>/dev/null; then
        return 1
    fi
    
    local result
    result=$(yq "${query} | select(. != null)" "${file}" 2>/dev/null)
    [[ -n "${result}" ]]
}
