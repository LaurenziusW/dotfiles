#!/usr/bin/env bash
# ==============================================================================
# UKE Window Manager Abstraction v7.0
# ==============================================================================
# Provides cross-platform window manager operations.
# ==============================================================================

[[ -n "${_UKE_WM_LOADED:-}" ]] && return 0
readonly _UKE_WM_LOADED=1

source "${UKE_LIB:-$(dirname "$0")}/core.sh"

# ==============================================================================
# Status
# ==============================================================================
wm_name() {
    is_macos && echo "yabai" || echo "hyprland"
}

wm_running() {
    if is_macos; then
        pgrep -q yabai
    else
        [[ -n "${HYPRLAND_INSTANCE_SIGNATURE:-}" ]]
    fi
}

# ==============================================================================
# Focus
# ==============================================================================
wm_focus() {
    local dir="$1"
    if is_macos; then
        case "$dir" in
            left|west)   yabai -m window --focus west ;;
            down|south)  yabai -m window --focus south ;;
            up|north)    yabai -m window --focus north ;;
            right|east)  yabai -m window --focus east ;;
        esac
    else
        local d
        case "$dir" in
            left|west)   d=l ;;
            down|south)  d=d ;;
            up|north)    d=u ;;
            right|east)  d=r ;;
        esac
        hyprctl dispatch movefocus "$d"
    fi
}

# ==============================================================================
# Move Window
# ==============================================================================
wm_move() {
    local dir="$1"
    if is_macos; then
        case "$dir" in
            left|west)   yabai -m window --warp west ;;
            down|south)  yabai -m window --warp south ;;
            up|north)    yabai -m window --warp north ;;
            right|east)  yabai -m window --warp east ;;
        esac
    else
        local d
        case "$dir" in
            left|west)   d=l ;;
            down|south)  d=d ;;
            up|north)    d=u ;;
            right|east)  d=r ;;
        esac
        hyprctl dispatch movewindow "$d"
    fi
}

# ==============================================================================
# Resize
# ==============================================================================
wm_resize() {
    local dir="$1"
    local amt="${2:-50}"
    
    if is_macos; then
        case "$dir" in
            left)  yabai -m window --resize left:-${amt}:0 ;;
            down)  yabai -m window --resize bottom:0:${amt} ;;
            up)    yabai -m window --resize top:0:-${amt} ;;
            right) yabai -m window --resize right:${amt}:0 ;;
        esac
    else
        case "$dir" in
            left)  hyprctl dispatch resizeactive -${amt} 0 ;;
            down)  hyprctl dispatch resizeactive 0 ${amt} ;;
            up)    hyprctl dispatch resizeactive 0 -${amt} ;;
            right) hyprctl dispatch resizeactive ${amt} 0 ;;
        esac
    fi
}

# ==============================================================================
# Workspace
# ==============================================================================
wm_workspace() {
    local ws="$1"
    if is_macos; then
        yabai -m space --focus "$ws"
    else
        hyprctl dispatch workspace "$ws"
    fi
}

wm_move_to_workspace() {
    local ws="$1"
    local follow="${2:-1}"
    
    if is_macos; then
        if [[ "$follow" == "1" ]]; then
            yabai -m window --space "$ws" --focus
        else
            yabai -m window --space "$ws"
        fi
    else
        if [[ "$follow" == "1" ]]; then
            hyprctl dispatch movetoworkspace "$ws"
        else
            hyprctl dispatch movetoworkspacesilent "$ws"
        fi
    fi
}

wm_current_workspace() {
    if is_macos; then
        yabai -m query --spaces --space 2>/dev/null | grep -o '"index":[0-9]*' | cut -d: -f2
    else
        hyprctl activeworkspace -j 2>/dev/null | grep -o '"id":[0-9]*' | cut -d: -f2
    fi
}

# ==============================================================================
# Window Controls
# ==============================================================================
wm_fullscreen() {
    if is_macos; then
        yabai -m window --toggle zoom-fullscreen
    else
        hyprctl dispatch fullscreen 0
    fi
}

wm_float() {
    if is_macos; then
        yabai -m window --toggle float
    else
        hyprctl dispatch togglefloating
    fi
}

wm_split() {
    if is_macos; then
        yabai -m window --toggle split
    else
        hyprctl dispatch togglesplit
    fi
}

wm_rotate() {
    if is_macos; then
        yabai -m space --rotate 90
    else
        hyprctl dispatch layoutmsg orientationcycle
    fi
}

wm_balance() {
    if is_macos; then
        yabai -m space --balance
    fi
    # Hyprland doesn't have an equivalent
}

wm_close() {
    if is_macos; then
        yabai -m window --close
    else
        hyprctl dispatch killactive
    fi
}

# ==============================================================================
# Query
# ==============================================================================
wm_windows() {
    local ws="${1:-}"
    
    if is_macos; then
        if [[ -n "$ws" ]]; then
            yabai -m query --windows --space "$ws"
        else
            yabai -m query --windows
        fi
    else
        local all
        all="$(hyprctl clients -j)"
        if [[ -n "$ws" ]]; then
            echo "$all" | jq "[.[] | select(.workspace.id == $ws)]"
        else
            echo "$all"
        fi
    fi
}

wm_displays() {
    if is_macos; then
        yabai -m query --displays
    else
        hyprctl monitors -j
    fi
}

# ==============================================================================
# Service Management
# ==============================================================================
wm_reload() {
    log_info "Reloading window manager..."
    if is_macos; then
        yabai --restart-service 2>/dev/null && ok "yabai restarted" || warn "yabai restart failed"
        skhd --restart-service 2>/dev/null && ok "skhd restarted" || warn "skhd restart failed"
    else
        hyprctl reload 2>/dev/null && ok "hyprland reloaded" || warn "hyprland reload failed"
    fi
}

wm_start() {
    if is_macos; then
        yabai --start-service 2>/dev/null
        skhd --start-service 2>/dev/null
    fi
    # Hyprland is typically started by the display manager
}

wm_stop() {
    if is_macos; then
        yabai --stop-service 2>/dev/null
        skhd --stop-service 2>/dev/null
    fi
}
