#!/usr/bin/env bash
# ==============================================================================
# UKE Profile Manager v7.0 - Hardware Configuration TUI
# ==============================================================================
# Interactive TUI for managing machine-specific hardware settings.
# Creates ~/.local/state/uke/machine.profile
#
# Usage: uke profile  OR  manage_profile.sh
# ==============================================================================
set -euo pipefail

# Require Bash 4+ for associative arrays
if ((BASH_VERSINFO[0] < 4)); then
    echo "Error: Bash 4.0+ required (found ${BASH_VERSION})"
    exit 1
fi

# ==============================================================================
# Resolve UKE Root
# ==============================================================================
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [[ -f "${SCRIPT_DIR}/../lib/core.sh" ]]; then
    export UKE_ROOT="${SCRIPT_DIR%/scripts}"
    source "${UKE_ROOT}/lib/core.sh"
else
    # Standalone mode - define minimal requirements
    UKE_STATE="${XDG_STATE_HOME:-$HOME/.local/state}/uke"
    mkdir -p "${UKE_STATE}"
fi

# ==============================================================================
# Configuration
# ==============================================================================
PROFILE_FILE="${UKE_STATE:-$HOME/.local/state/uke}/machine.profile"
APPLY_SCRIPT="${SCRIPT_DIR}/apply_profile.sh"

# ==============================================================================
# Option Arrays (for cycling)
# ==============================================================================
declare -a OS_OPTIONS=("arch" "macos")
declare -a FORM_FACTOR_OPTIONS=("desktop" "laptop_14" "laptop_10")
declare -a MONITORS_OPTIONS=("1" "2" "3")
declare -a GPU_OPTIONS=("integrated" "nvidia" "amd")
declare -a KEYBOARD_OPTIONS=("pc" "mac")

# ==============================================================================
# Current Values
# ==============================================================================
declare PROFILE_OS=""
declare PROFILE_FORM_FACTOR=""
declare PROFILE_MONITORS=""
declare PROFILE_GPU=""
declare PROFILE_KEYBOARD=""

# Track if changes were made
declare CHANGES_MADE=false

# ==============================================================================
# Colors (only define if not already declared)
# ==============================================================================
if ! declare -p C_RED &>/dev/null; then
    if [[ -t 1 ]]; then
        readonly C_RED=$'\e[31m'
        readonly C_GREEN=$'\e[32m'
        readonly C_YELLOW=$'\e[33m'
        readonly C_BLUE=$'\e[34m'
        readonly C_CYAN=$'\e[36m'
        readonly C_BOLD=$'\e[1m'
        readonly C_DIM=$'\e[2m'
        readonly C_RESET=$'\e[0m'
        readonly C_INVERSE=$'\e[7m'
    else
        readonly C_RED='' C_GREEN='' C_YELLOW='' C_BLUE=''
        readonly C_CYAN='' C_BOLD='' C_DIM='' C_RESET='' C_INVERSE=''
    fi
fi

# ==============================================================================
# Utility Functions (only define if not already set)
# ==============================================================================
if ! declare -f ok &>/dev/null; then
    ok()   { printf "%s✓%s %s\n" "${C_GREEN}" "${C_RESET}" "$*"; }
    warn() { printf "%s!%s %s\n" "${C_YELLOW}" "${C_RESET}" "$*"; }
    fail() { printf "%s✗%s %s\n" "${C_RED}" "${C_RESET}" "$*"; }
    info() { printf "%s→%s %s\n" "${C_BLUE}" "${C_RESET}" "$*"; }
fi

clear_screen() { printf '\033[2J\033[H'; }

# ==============================================================================
# Hardware Detection (Auto-detect on first run)
# ==============================================================================
detect_os() {
    case "$(uname -s)" in
        Darwin) echo "macos" ;;
        Linux)  echo "arch" ;;
        *)      echo "arch" ;;
    esac
}

detect_form_factor() {
    if [[ "$(uname -s)" == "Darwin" ]]; then
        if system_profiler SPDisplaysDataType 2>/dev/null | grep -q "Built-in"; then
            echo "laptop_14"
        else
            echo "desktop"
        fi
    else
        # Linux: check for laptop battery
        if [[ -d /sys/class/power_supply/BAT0 ]] || [[ -d /sys/class/power_supply/BAT1 ]]; then
            echo "laptop_14"
        else
            echo "desktop"
        fi
    fi
}

detect_gpu() {
    if [[ "$(uname -s)" == "Darwin" ]]; then
        # macOS: check for discrete GPU
        if system_profiler SPDisplaysDataType 2>/dev/null | grep -qi "nvidia\|radeon"; then
            echo "nvidia"  # or amd, simplified
        else
            echo "integrated"
        fi
    else
        # Linux
        if command -v lspci &>/dev/null; then
            if lspci 2>/dev/null | grep -qi nvidia; then
                echo "nvidia"
            elif lspci 2>/dev/null | grep -qi "amd\|radeon"; then
                echo "amd"
            else
                echo "integrated"
            fi
        else
            echo "integrated"
        fi
    fi
}

detect_monitors() {
    if [[ "$(uname -s)" == "Darwin" ]]; then
        local count
        count=$(system_profiler SPDisplaysDataType 2>/dev/null | grep -c "Resolution:" || echo "1")
        echo "${count}"
    else
        if command -v hyprctl &>/dev/null && [[ -n "${HYPRLAND_INSTANCE_SIGNATURE:-}" ]]; then
            hyprctl monitors -j 2>/dev/null | jq 'length' || echo "1"
        elif command -v xrandr &>/dev/null; then
            xrandr --query 2>/dev/null | grep -c " connected" || echo "1"
        else
            echo "1"
        fi
    fi
}

# ==============================================================================
# Profile Management
# ==============================================================================
init_defaults() {
    PROFILE_OS="$(detect_os)"
    PROFILE_FORM_FACTOR="$(detect_form_factor)"
    PROFILE_MONITORS="$(detect_monitors)"
    PROFILE_GPU="$(detect_gpu)"
    
    # Keyboard defaults based on OS
    if [[ "${PROFILE_OS}" == "macos" ]]; then
        PROFILE_KEYBOARD="mac"
    else
        PROFILE_KEYBOARD="pc"
    fi
}

load_profile() {
    mkdir -p "$(dirname "${PROFILE_FILE}")"
    
    if [[ -f "${PROFILE_FILE}" ]]; then
        # shellcheck source=/dev/null
        source "${PROFILE_FILE}"
        
        # Map exported variables to local ones
        PROFILE_OS="${UKE_HW_OS:-$(detect_os)}"
        PROFILE_FORM_FACTOR="${UKE_HW_FORM_FACTOR:-desktop}"
        PROFILE_MONITORS="${UKE_HW_MONITORS:-1}"
        PROFILE_GPU="${UKE_HW_GPU:-integrated}"
        PROFILE_KEYBOARD="${UKE_HW_KEYBOARD:-pc}"
        return 0
    fi
    return 1
}

save_profile() {
    mkdir -p "$(dirname "${PROFILE_FILE}")"
    
    local temp_file
    temp_file=$(mktemp)
    
    cat > "${temp_file}" << EOF
# ==============================================================================
# UKE Machine Profile - Hardware Configuration
# ==============================================================================
# Generated by: manage_profile.sh
# Updated: $(date -Iseconds)
#
# Edit via TUI: uke profile
# Regenerate configs after editing: uke gen && uke reload
# ==============================================================================

# Operating System
export UKE_HW_OS="${PROFILE_OS}"

# Form Factor (affects font sizes, gaps, padding)
#   desktop   - External monitor, standard gaps
#   laptop_14 - 14" laptop, slightly larger fonts
#   laptop_10 - Small/portable, minimal gaps
export UKE_HW_FORM_FACTOR="${PROFILE_FORM_FACTOR}"

# Number of Monitors (affects workspace assignment)
export UKE_HW_MONITORS="${PROFILE_MONITORS}"

# GPU Type (affects Wayland environment variables)
#   integrated - No special settings
#   nvidia     - WLR_NO_HARDWARE_CURSORS, etc.
#   amd        - AMD-specific settings
export UKE_HW_GPU="${PROFILE_GPU}"

# Keyboard Layout Style
#   pc  - Standard PC keyboard
#   mac - Mac keyboard (swap Alt/Super)
export UKE_HW_KEYBOARD="${PROFILE_KEYBOARD}"
EOF
    
    mv "${temp_file}" "${PROFILE_FILE}"
    chmod 600 "${PROFILE_FILE}"
    CHANGES_MADE=false
}

# ==============================================================================
# Option Cycling
# ==============================================================================
get_index() {
    local value="$1"
    shift
    local -a options=("$@")
    local i
    
    for i in "${!options[@]}"; do
        if [[ "${options[$i]}" == "${value}" ]]; then
            echo "$i"
            return 0
        fi
    done
    echo "0"
}

cycle_next() {
    local value="$1"
    shift
    local -a options=("$@")
    local idx
    
    idx=$(get_index "${value}" "${options[@]}")
    local next_idx=$(( (idx + 1) % ${#options[@]} ))
    CHANGES_MADE=true
    echo "${options[$next_idx]}"
}

# ==============================================================================
# Display Functions
# ==============================================================================
print_header() {
    printf "%s╔══════════════════════════════════════════════════════════════════╗%s\n" "${C_CYAN}" "${C_RESET}"
    printf "%s║%s         UKE Profile Manager - Hardware Configuration            %s║%s\n" "${C_CYAN}" "${C_BOLD}" "${C_CYAN}" "${C_RESET}"
    printf "%s╚══════════════════════════════════════════════════════════════════╝%s\n" "${C_CYAN}" "${C_RESET}"
    echo ""
}

print_option_bar() {
    local current="$1"
    shift
    local -a options=("$@")
    
    local result=""
    local opt
    for opt in "${options[@]}"; do
        if [[ "${opt}" == "${current}" ]]; then
            result+="${C_GREEN}${C_BOLD}[${opt}]${C_RESET} "
        else
            result+="${C_DIM}${opt}${C_RESET} "
        fi
    done
    echo "${result}"
}

print_value_row() {
    local key="$1"
    local label="$2"
    local current="$3"
    shift 3
    local -a options=("$@")
    
    local bar
    bar=$(print_option_bar "${current}" "${options[@]}")
    
    printf "  %s[%s]%s %-15s %s\n" "${C_YELLOW}" "${key}" "${C_RESET}" "${label}:" "${bar}"
}

print_dashboard() {
    clear_screen
    print_header
    
    # Status indicator
    if ${CHANGES_MADE}; then
        printf "  %s● Unsaved changes%s\n\n" "${C_YELLOW}" "${C_RESET}"
    else
        printf "  %s● Profile saved%s\n\n" "${C_GREEN}" "${C_RESET}"
    fi
    
    printf "%sCurrent Configuration:%s\n\n" "${C_BOLD}" "${C_RESET}"
    
    print_value_row "1" "OS" "${PROFILE_OS}" "${OS_OPTIONS[@]}"
    print_value_row "2" "Form Factor" "${PROFILE_FORM_FACTOR}" "${FORM_FACTOR_OPTIONS[@]}"
    print_value_row "3" "Monitors" "${PROFILE_MONITORS}" "${MONITORS_OPTIONS[@]}"
    print_value_row "4" "GPU" "${PROFILE_GPU}" "${GPU_OPTIONS[@]}"
    print_value_row "5" "Keyboard" "${PROFILE_KEYBOARD}" "${KEYBOARD_OPTIONS[@]}"
    
    echo ""
    
    # Form factor preview
    printf "%sEffect Preview:%s\n" "${C_DIM}" "${C_RESET}"
    case "${PROFILE_FORM_FACTOR}" in
        desktop)    printf "  Font: 11pt │ Gaps: 6px │ Borders: 2px\n" ;;
        laptop_14)  printf "  Font: 12.5pt │ Gaps: 4px │ Borders: 2px\n" ;;
        laptop_10)  printf "  Font: 10pt │ Gaps: 2px │ Borders: 1px\n" ;;
    esac
    
    if [[ "${PROFILE_GPU}" == "nvidia" ]]; then
        printf "  GPU: NVIDIA env vars enabled (WLR_NO_HARDWARE_CURSORS)\n"
    fi
    
    echo ""
    printf "%s────────────────────────────────────────────────────────────────────%s\n" "${C_DIM}" "${C_RESET}"
    echo ""
    printf "  %s[1-5]%s Cycle   %s[s]%s Save & Generate   %s[r]%s Reset   %s[q]%s Quit\n" \
        "${C_YELLOW}" "${C_RESET}" \
        "${C_GREEN}" "${C_RESET}" \
        "${C_BLUE}" "${C_RESET}" \
        "${C_RED}" "${C_RESET}"
    echo ""
}

# ==============================================================================
# Actions
# ==============================================================================
apply_changes() {
    save_profile
    ok "Profile saved to ${PROFILE_FILE}"
    
    if [[ -x "${APPLY_SCRIPT}" ]]; then
        echo ""
        info "Generating hardware-specific configs..."
        echo ""
        if bash "${APPLY_SCRIPT}"; then
            echo ""
            ok "Hardware configs generated!"
            echo ""
            info "Run 'uke gen && uke reload' to apply all changes"
        else
            fail "Config generation failed!"
        fi
    else
        warn "apply_profile.sh not found at ${APPLY_SCRIPT}"
        info "Generate manually: ${APPLY_SCRIPT}"
    fi
    
    echo ""
    printf "Press any key to continue..."
    read -r -n1 -s
}

reset_to_defaults() {
    info "Auto-detecting hardware..."
    init_defaults
    CHANGES_MADE=true
    ok "Reset to auto-detected values"
    sleep 1
}

quit_handler() {
    if ${CHANGES_MADE}; then
        echo ""
        printf "  %sUnsaved changes!%s Save before quitting? [y/N] " "${C_YELLOW}" "${C_RESET}"
        read -r -n1 response
        echo ""
        if [[ "${response}" =~ ^[Yy]$ ]]; then
            apply_changes
        fi
    fi
    clear_screen
    info "Exiting UKE Profile Manager"
}

# ==============================================================================
# Main Loop
# ==============================================================================
main() {
    # First run detection
    if ! load_profile; then
        info "First run detected - auto-detecting hardware..."
        init_defaults
        save_profile
        
        if [[ -x "${APPLY_SCRIPT}" ]]; then
            bash "${APPLY_SCRIPT}"
        fi
        
        ok "Profile initialized with auto-detected settings"
        sleep 1
    fi
    
    local running=true
    while ${running}; do
        print_dashboard
        
        printf "  Choice: "
        read -r -n1 choice
        echo ""
        
        case "${choice}" in
            1) PROFILE_OS=$(cycle_next "${PROFILE_OS}" "${OS_OPTIONS[@]}") ;;
            2) PROFILE_FORM_FACTOR=$(cycle_next "${PROFILE_FORM_FACTOR}" "${FORM_FACTOR_OPTIONS[@]}") ;;
            3) PROFILE_MONITORS=$(cycle_next "${PROFILE_MONITORS}" "${MONITORS_OPTIONS[@]}") ;;
            4) PROFILE_GPU=$(cycle_next "${PROFILE_GPU}" "${GPU_OPTIONS[@]}") ;;
            5) PROFILE_KEYBOARD=$(cycle_next "${PROFILE_KEYBOARD}" "${KEYBOARD_OPTIONS[@]}") ;;
            s|S) apply_changes ;;
            r|R) reset_to_defaults ;;
            q|Q) running=false ;;
            $'\e'|$'\x1b') running=false ;;  # ESC key
            *) ;;
        esac
    done
    
    quit_handler
}

# ==============================================================================
# Entry Point
# ==============================================================================
case "${1:-}" in
    --help|-h)
        cat << 'EOF'
UKE Profile Manager - Hardware Configuration TUI

Usage:
  manage_profile.sh          Interactive TUI
  manage_profile.sh --show   Show current profile
  manage_profile.sh --reset  Reset to auto-detected values

The profile controls hardware-specific settings like:
  - Font sizes (based on form factor)
  - Window gaps and padding
  - GPU-specific environment variables
  - Multi-monitor workspace assignment
EOF
        ;;
    --show)
        if [[ -f "${PROFILE_FILE}" ]]; then
            cat "${PROFILE_FILE}"
        else
            fail "No profile found at ${PROFILE_FILE}"
            exit 1
        fi
        ;;
    --reset)
        init_defaults
        save_profile
        ok "Profile reset to auto-detected values"
        cat "${PROFILE_FILE}"
        ;;
    *)
        main
        ;;
esac
