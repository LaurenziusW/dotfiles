#!/usr/bin/env bash
# ==============================================================================
# UKE Profile Manager - Hardware Configuration TUI
# ==============================================================================
# A terminal UI for managing machine-specific settings.
# Creates ~/.local/state/uke/machine.profile with hardware configuration.
#
# Usage: manage_profile.sh
# ==============================================================================
set -euo pipefail

# Require Bash 4+ for associative arrays
if ((BASH_VERSINFO[0] < 4)); then
    echo "Error: Bash 4.0+ required (found ${BASH_VERSION})"
    exit 1
fi

# ==============================================================================
# Configuration
# ==============================================================================
PROFILE_DIR="${HOME}/.local/state/uke"
PROFILE_FILE="${PROFILE_DIR}/machine.profile"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
APPLY_SCRIPT="${SCRIPT_DIR}/apply_profile.sh"

# ==============================================================================
# Option Arrays (for cycling)
# ==============================================================================
declare -a OS_OPTIONS=("arch" "macos")
declare -a FORM_FACTOR_OPTIONS=("desktop" "laptop_14" "laptop_10")
declare -a MONITORS_OPTIONS=("1" "2")
declare -a GPU_OPTIONS=("integrated" "nvidia")
declare -a KEYBOARD_OPTIONS=("pc" "mac")

# ==============================================================================
# Current Values (loaded from profile or defaults)
# ==============================================================================
declare PROFILE_OS=""
declare PROFILE_FORM_FACTOR=""
declare PROFILE_MONITORS=""
declare PROFILE_GPU=""
declare PROFILE_KEYBOARD=""

# ==============================================================================
# Colors
# ==============================================================================
if [[ -t 1 ]]; then
    readonly C_RED=$'\e[31m'
    readonly C_GREEN=$'\e[32m'
    readonly C_YELLOW=$'\e[33m'
    readonly C_BLUE=$'\e[34m'
    readonly C_MAGENTA=$'\e[35m'
    readonly C_CYAN=$'\e[36m'
    readonly C_BOLD=$'\e[1m'
    readonly C_DIM=$'\e[2m'
    readonly C_RESET=$'\e[0m'
else
    readonly C_RED='' C_GREEN='' C_YELLOW='' C_BLUE=''
    readonly C_MAGENTA='' C_CYAN='' C_BOLD='' C_DIM='' C_RESET=''
fi

# ==============================================================================
# Utility Functions
# ==============================================================================
ok()   { printf "%s✓%s %s\n" "${C_GREEN}" "${C_RESET}" "$*"; }
warn() { printf "%s!%s %s\n" "${C_YELLOW}" "${C_RESET}" "$*"; }
fail() { printf "%s✗%s %s\n" "${C_RED}" "${C_RESET}" "$*"; }
info() { printf "%s→%s %s\n" "${C_BLUE}" "${C_RESET}" "$*"; }

# Clear screen and move cursor to top
clear_screen() {
    printf '\033[2J\033[H'
}

# Detect OS automatically
detect_os() {
    case "$(uname -s)" in
        Darwin) echo "macos" ;;
        Linux)  echo "arch" ;;
        *)      echo "arch" ;;
    esac
}

# Detect form factor (heuristic based on display)
detect_form_factor() {
    if [[ "$(uname -s)" == "Darwin" ]]; then
        # macOS: check if we have a built-in display
        if system_profiler SPDisplaysDataType 2>/dev/null | grep -q "Built-in"; then
            echo "laptop_14"
        else
            echo "desktop"
        fi
    else
        # Linux: check for laptop battery
        if [[ -d /sys/class/power_supply/BAT0 ]] || [[ -d /sys/class/power_supply/BAT1 ]]; then
            echo "laptop_14"
        else
            echo "desktop"
        fi
    fi
}

# Detect GPU
detect_gpu() {
    if command -v lspci &>/dev/null; then
        if lspci 2>/dev/null | grep -qi nvidia; then
            echo "nvidia"
        else
            echo "integrated"
        fi
    else
        echo "integrated"
    fi
}

# ==============================================================================
# Profile Management
# ==============================================================================
init_defaults() {
    PROFILE_OS="$(detect_os)"
    PROFILE_FORM_FACTOR="$(detect_form_factor)"
    PROFILE_MONITORS="1"
    PROFILE_GPU="$(detect_gpu)"
    
    # Keyboard defaults based on OS
    if [[ "${PROFILE_OS}" == "macos" ]]; then
        PROFILE_KEYBOARD="mac"
    else
        PROFILE_KEYBOARD="pc"
    fi
}

load_profile() {
    # Ensure directory exists
    mkdir -p "${PROFILE_DIR}"
    
    if [[ -f "${PROFILE_FILE}" ]]; then
        # Source existing profile (safe because we control the format)
        # shellcheck source=/dev/null
        source "${PROFILE_FILE}"
        
        # Map to local variables
        PROFILE_OS="${UKE_OS:-$(detect_os)}"
        PROFILE_FORM_FACTOR="${UKE_FORM_FACTOR:-desktop}"
        PROFILE_MONITORS="${UKE_MONITORS:-1}"
        PROFILE_GPU="${UKE_GPU:-integrated}"
        PROFILE_KEYBOARD="${UKE_KEYBOARD:-pc}"
    else
        # First run - initialize with auto-detected defaults
        init_defaults
        save_profile
        ok "Initialized new profile with auto-detected settings"
        sleep 1
    fi
}

save_profile() {
    mkdir -p "${PROFILE_DIR}"
    
    # Use temp file for atomic write
    local temp_file
    temp_file=$(mktemp)
    
    cat > "${temp_file}" << EOF
# ==============================================================================
# UKE Machine Profile - DO NOT EDIT MANUALLY
# ==============================================================================
# Generated by manage_profile.sh
# Last updated: $(date -Iseconds)
# ==============================================================================

export UKE_OS="${PROFILE_OS}"
export UKE_FORM_FACTOR="${PROFILE_FORM_FACTOR}"
export UKE_MONITORS="${PROFILE_MONITORS}"
export UKE_GPU="${PROFILE_GPU}"
export UKE_KEYBOARD="${PROFILE_KEYBOARD}"
EOF
    
    mv "${temp_file}" "${PROFILE_FILE}"
    chmod 600 "${PROFILE_FILE}"
}

# ==============================================================================
# Option Cycling
# ==============================================================================
# Get current index in array
get_index() {
    local value="$1"
    shift
    local -a options=("$@")
    local i
    
    for i in "${!options[@]}"; do
        if [[ "${options[$i]}" == "${value}" ]]; then
            echo "$i"
            return 0
        fi
    done
    echo "0"
}

# Cycle to next value in array
cycle_next() {
    local value="$1"
    shift
    local -a options=("$@")
    local idx
    
    idx=$(get_index "${value}" "${options[@]}")
    local next_idx=$(( (idx + 1) % ${#options[@]} ))
    echo "${options[$next_idx]}"
}

# ==============================================================================
# Display Functions
# ==============================================================================
print_header() {
    printf "%s╔══════════════════════════════════════════════════════════════╗%s\n" "${C_CYAN}" "${C_RESET}"
    printf "%s║%s       UKE Profile Manager - Hardware Configuration         %s║%s\n" "${C_CYAN}" "${C_BOLD}" "${C_CYAN}" "${C_RESET}"
    printf "%s╚══════════════════════════════════════════════════════════════╝%s\n" "${C_CYAN}" "${C_RESET}"
    echo ""
}

print_value() {
    local label="$1"
    local value="$2"
    local key="$3"
    local -a options=("${@:4}")
    
    # Format options string
    local options_str=""
    local opt
    for opt in "${options[@]}"; do
        if [[ "${opt}" == "${value}" ]]; then
            options_str+="${C_GREEN}${C_BOLD}${opt}${C_RESET} "
        else
            options_str+="${C_DIM}${opt}${C_RESET} "
        fi
    done
    
    printf "  %s[%s]%s %-15s %s\n" "${C_YELLOW}" "${key}" "${C_RESET}" "${label}:" "${options_str}"
}

print_dashboard() {
    clear_screen
    print_header
    
    printf "%sCurrent Configuration:%s\n\n" "${C_BOLD}" "${C_RESET}"
    
    print_value "OS" "${PROFILE_OS}" "1" "${OS_OPTIONS[@]}"
    print_value "Form Factor" "${PROFILE_FORM_FACTOR}" "2" "${FORM_FACTOR_OPTIONS[@]}"
    print_value "Monitors" "${PROFILE_MONITORS}" "3" "${MONITORS_OPTIONS[@]}"
    print_value "GPU" "${PROFILE_GPU}" "4" "${GPU_OPTIONS[@]}"
    print_value "Keyboard" "${PROFILE_KEYBOARD}" "5" "${KEYBOARD_OPTIONS[@]}"
    
    echo ""
    printf "%s────────────────────────────────────────────────────────────────%s\n" "${C_DIM}" "${C_RESET}"
    echo ""
    printf "  %s[1-5]%s Cycle option   %s[s]%s Save & Apply   %s[r]%s Reset to auto-detect   %s[q]%s Quit\n" \
        "${C_YELLOW}" "${C_RESET}" \
        "${C_GREEN}" "${C_RESET}" \
        "${C_BLUE}" "${C_RESET}" \
        "${C_RED}" "${C_RESET}"
    echo ""
}

# ==============================================================================
# Actions
# ==============================================================================
apply_changes() {
    save_profile
    ok "Profile saved to ${PROFILE_FILE}"
    
    if [[ -x "${APPLY_SCRIPT}" ]]; then
        echo ""
        info "Generating hardware-specific configs..."
        echo ""
        if bash "${APPLY_SCRIPT}"; then
            ok "Configs generated successfully!"
        else
            fail "Config generation failed!"
        fi
    else
        warn "apply_profile.sh not found or not executable"
        warn "Expected at: ${APPLY_SCRIPT}"
    fi
    
    echo ""
    printf "Press any key to continue..."
    read -r -n1 -s
}

reset_to_defaults() {
    info "Auto-detecting hardware..."
    init_defaults
    ok "Reset to auto-detected values"
    sleep 1
}

# ==============================================================================
# Main Loop
# ==============================================================================
main() {
    load_profile
    
    local running=true
    while ${running}; do
        print_dashboard
        
        printf "  Choice: "
        read -r -n1 choice
        echo ""
        
        case "${choice}" in
            1) PROFILE_OS=$(cycle_next "${PROFILE_OS}" "${OS_OPTIONS[@]}") ;;
            2) PROFILE_FORM_FACTOR=$(cycle_next "${PROFILE_FORM_FACTOR}" "${FORM_FACTOR_OPTIONS[@]}") ;;
            3) PROFILE_MONITORS=$(cycle_next "${PROFILE_MONITORS}" "${MONITORS_OPTIONS[@]}") ;;
            4) PROFILE_GPU=$(cycle_next "${PROFILE_GPU}" "${GPU_OPTIONS[@]}") ;;
            5) PROFILE_KEYBOARD=$(cycle_next "${PROFILE_KEYBOARD}" "${KEYBOARD_OPTIONS[@]}") ;;
            s|S) apply_changes ;;
            r|R) reset_to_defaults ;;
            q|Q) running=false ;;
            *) ;;  # Ignore invalid input
        esac
    done
    
    clear_screen
    info "Exiting UKE Profile Manager"
}

main "$@"
