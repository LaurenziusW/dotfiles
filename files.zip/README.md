# UKE Ghost Files Architecture

A hardware-agnostic dotfiles system where **tools are version-controlled** but **state and artifacts are local-only**.

## Philosophy

```
┌─────────────────────────────────────────────────────────────────────────┐
│                         VERSION CONTROLLED                              │
│  ┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐   │
│  │ manage_profile  │────▶│  apply_profile  │────▶│  Main Configs   │   │
│  │     (TUI)       │     │   (Generator)   │     │  (source ...)   │   │
│  └─────────────────┘     └─────────────────┘     └─────────────────┘   │
└─────────────────────────────────────────────────────────────────────────┘
                 │                    │
                 ▼                    ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                         LOCAL ONLY (.gitignored)                        │
│  ┌─────────────────┐     ┌─────────────────────────────────────────┐   │
│  │ machine.profile │     │  generated_hardware.conf                 │   │
│  │                 │     │  generated_font.toml                     │   │
│  │  UKE_OS=arch    │     │  generated_hardware.lua                  │   │
│  │  UKE_GPU=nvidia │     │                                          │   │
│  │  ...            │     │                                          │   │
│  └─────────────────┘     └─────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────────┘
```

## Quick Start

```bash
# 1. Run the profile manager
./scripts/manage_profile.sh

# 2. Cycle through options with number keys [1-5]
# 3. Press [s] to save and auto-generate configs
# 4. Press [q] to quit

# Manual regeneration (if needed)
./scripts/apply_profile.sh

# Dry run to see what would be generated
./scripts/apply_profile.sh --dry-run
```

## Data Model

| Variable | Options | Description |
|----------|---------|-------------|
| `UKE_OS` | `arch`, `macos` | Operating system |
| `UKE_FORM_FACTOR` | `desktop`, `laptop_14`, `laptop_10` | Display size category |
| `UKE_MONITORS` | `1`, `2` | Number of monitors |
| `UKE_GPU` | `integrated`, `nvidia` | GPU type |
| `UKE_KEYBOARD` | `pc`, `mac` | Keyboard layout style |

## File Locations

### Version Controlled (commit these)
```
~/dotfiles/uke/
├── scripts/
│   ├── manage_profile.sh    # TUI for managing settings
│   └── apply_profile.sh     # Generator script
├── config/
│   └── registry.yaml        # Main UKE config
└── gen/
    ├── hyprland/
    │   └── hyprland.conf     # Template (sources generated file)
    └── ...
```

### Local Only (gitignored)
```
~/.local/state/uke/
└── machine.profile           # Hardware settings

~/.config/hypr/
└── generated_hardware.conf   # GPU, monitors, gaps

~/.config/alacritty/
└── generated_font.toml       # Font size for display

~/.config/wezterm/
└── generated_hardware.lua    # Font size, GPU settings

~/.config/yabai/
└── generated_hardware.conf   # Padding, gaps (macOS)
```

## Form Factor → Font Size Mapping

| Form Factor | Font Size | Use Case |
|-------------|-----------|----------|
| `desktop` | 11.0 | External monitor, comfortable viewing |
| `laptop_14` | 12.5 | Standard laptop, slightly larger for readability |
| `laptop_10` | 10.0 | Small/portable device, maximize content |

## GPU-Specific Settings

### NVIDIA (Hyprland)
When `UKE_GPU=nvidia`, the following environment variables are set:
```conf
env = LIBVA_DRIVER_NAME,nvidia
env = XDG_SESSION_TYPE,wayland
env = GBM_BACKEND,nvidia-drm
env = __GLX_VENDOR_LIBRARY_NAME,nvidia
env = WLR_NO_HARDWARE_CURSORS,1
```

### Integrated
No special settings needed.

## Multi-Monitor Setup

When `UKE_MONITORS=2`, workspace assignments are generated:
- Workspaces 1-5: Primary monitor (eDP-1)
- Workspaces 6-10: Secondary monitor (HDMI-A-1)

**Important:** Edit the generated file to match your actual monitor names.
Use `hyprctl monitors` to find your monitor identifiers.

## Fresh Clone Workflow

After cloning to a new machine:

```bash
# 1. Clone your dotfiles
git clone <your-repo> ~/dotfiles
cd ~/dotfiles/uke

# 2. Run install (checks dependencies)
./scripts/install.sh --check

# 3. Create machine profile (auto-detects hardware)
./scripts/manage_profile.sh
# Press [s] to save with auto-detected settings
# Or adjust settings first, then save

# 4. Reload window manager
hyprctl reload  # Linux
# or
yabai --restart-service  # macOS
```

## Safety Features

### Idempotency
- Scripts can run 100+ times without issues
- Generated files are completely overwritten (not appended)
- Uses atomic temp file + move pattern

### Fresh Clone Handling
- All directories created with `mkdir -p`
- Profile auto-initialized on first run
- Scripts fail gracefully with helpful messages

### Shellcheck Compliance
- All variables properly quoted
- Uses `${var:-default}` for safety
- Compatible with `set -euo pipefail`

## Integration with Existing Configs

### Hyprland
Add to the **end** of `hyprland.conf`:
```conf
source = ~/.config/hypr/generated_hardware.conf
```

### Alacritty
Add to `alacritty.toml`:
```toml
[general]
import = ["~/.config/alacritty/generated_font.toml"]
```

### WezTerm
Add to `.wezterm.lua`:
```lua
local hw = dofile(wezterm.home_dir .. "/.config/wezterm/generated_hardware.lua")
config.font_size = hw.font_size
```

See `INTEGRATION.md` for complete snippets.

## Troubleshooting

### Profile not found
```
✗ Profile not found: ~/.local/state/uke/machine.profile
```
**Solution:** Run `manage_profile.sh` to create the profile.

### Generated configs missing
Check if the apply script ran successfully:
```bash
./scripts/apply_profile.sh --dry-run
```

### Wrong monitor names
Edit `~/.config/hypr/generated_hardware.conf` to match your actual monitors.
Run `hyprctl monitors` to find the correct names.

### Variables not exported
Ensure your profile uses the correct format:
```bash
export UKE_OS="arch"  # Correct
UKE_OS=arch           # Wrong - missing export
```

## Contributing

When adding new hardware variables:

1. Add to the options array in `manage_profile.sh`
2. Add detection logic in `detect_*()` functions
3. Add generation logic in `apply_profile.sh`
4. Update this README
