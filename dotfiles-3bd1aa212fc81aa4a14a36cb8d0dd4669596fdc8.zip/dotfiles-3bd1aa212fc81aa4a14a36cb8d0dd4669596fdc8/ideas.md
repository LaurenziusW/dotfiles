Have .md viewer in nvim.
have easy documentation download to environment.
have alias to search/ask AI inside commandline about syntax
search history wezterm and be able to copy without using mouse